package com.tradingai.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaMetadataRetriever;

public class MainActivity extends AppCompatActivity {

    private TextView selectedText, statusText, resultText;
    private ProgressBar progress;
    private Uri selectedVideo;

    private final ActivityResultLauncher<String> videoPicker =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) {
                selectedVideo = uri;
                selectedText.setText("الفيديو المختار:\n" + getFileName(uri));
                statusText.setText("جاهز للتحليل");
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xFFF7F9FC);

        TextView title = new TextView(this);
        title.setText("Trading AI");
        title.setTextSize(30);
        title.setTextColor(0xFF1565C0);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, lp(WRAP, 70));

        TextView subtitle = new TextView(this);
        subtitle.setText("تحليل فيديو التداول وفهم الشارت");
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFF333333);
        root.addView(subtitle, lp(WRAP, 55));

        Button choose = new Button(this);
        choose.setText("🎥  رفع فيديو التداول");
        choose.setTextSize(17);
        root.addView(choose, lp(WRAP, 62));

        selectedText = new TextView(this);
        selectedText.setText("لم يتم اختيار فيديو");
        selectedText.setTextSize(15);
        selectedText.setPadding(12, 15, 12, 15);
        root.addView(selectedText, lp(WRAP, 80));

        Button analyze = new Button(this);
        analyze.setText("🧠  تحليل الشارت");
        analyze.setTextSize(17);
        root.addView(analyze, lp(WRAP, 62));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setVisibility(View.GONE);
        root.addView(progress, lp(WRAP, 30));

        statusText = new TextView(this);
        statusText.setText("اختر فيديو للبدء");
        statusText.setTextSize(15);
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, lp(WRAP, 50));

        TextView heading = new TextView(this);
        heading.setText("نتيجة التحليل");
        heading.setTextSize(20);
        heading.setTypeface(null, 1);
        heading.setPadding(0, 20, 0, 10);
        root.addView(heading, lp(WRAP, 55));

        resultText = new TextView(this);
        resultText.setText("ستظهر هنا معلومات الشارت بعد التحليل.");
        resultText.setTextSize(16);
        resultText.setPadding(20, 20, 20, 20);
        resultText.setBackgroundColor(0xFFFFFFFF);
        root.addView(resultText, new LinearLayout.LayoutParams(WRAP, 0, 1));

        choose.setOnClickListener(v -> videoPicker.launch("video/*"));
        analyze.setOnClickListener(v -> analyzeVideo());

        setContentView(root);
    }

    private void analyzeVideo() {
        if (selectedVideo == null) {
            Toast.makeText(this, "اختر فيديو أولاً", Toast.LENGTH_SHORT).show();
            return;
        }

        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        statusText.setText("جاري قراءة الفيديو واستخراج بياناته...");
        resultText.setText("جاري التحليل...");

        new Thread(() -> {
            String result = inspectVideo(selectedVideo);

            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                statusText.setText("اكتمل التحليل الأولي");
                resultText.setText(result);
            });
        }).start();
    }

    /*
     * النسخة الأولى تقرأ خصائص الفيديو محلياً.
     * في النسخة المتصلة بالذكاء الاصطناعي، هذه النقطة سترسل لقطات
     * الشارت إلى خادم AI وتستقبل BOS/FVG/CHOCH وغيرها.
     */
    private String inspectVideo(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            String durationMs = r.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION);
            long ms = durationMs == null ? 0 : Long.parseLong(durationMs);
            long seconds = ms / 1000;

            return "الفيديو: " + getFileName(uri)
                    + "\nالمدة: " + seconds + " ثانية"
                    + "\n\nالتحليل البصري المتقدم سيضاف في طبقة AI."
                    + "\n\nالحالة الحالية:"
                    + "\n✓ تم اختيار الفيديو"
                    + "\n✓ تم فتح الفيديو"
                    + "\n✓ تم قراءة مدته"
                    + "\n○ تحليل الشموع"
                    + "\n○ BOS / CHOCH"
                    + "\n○ FVG"
                    + "\n○ Liquidity Sweep"
                    + "\n○ استخراج Entry / SL / TP";
        } catch (Exception e) {
            return "تعذر قراءة الفيديو:\n" + e.getMessage();
        } finally {
            r.release();
        }
    }

    private String getFileName(Uri uri) {
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (c.moveToFirst() && idx >= 0) return c.getString(idx);
            } finally {
                c.close();
            }
        }
        return uri.getLastPathSegment() == null ? "video" : uri.getLastPathSegment();
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }
}
