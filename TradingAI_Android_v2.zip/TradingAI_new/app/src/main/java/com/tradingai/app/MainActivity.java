package com.tradingai.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("TradingAI");
        title.setTextSize(28);
        root.addView(title, lp(WRAP, 70));

        TextView subtitle = new TextView(this);
        subtitle.setText("مساعد تحليل تداول - النسخة الأولى");
        subtitle.setTextSize(18);
        root.addView(subtitle, lp(WRAP, 55));

        Button analyze = new Button(this);
        analyze.setText("بدء التحليل");
        root.addView(analyze, lp(WRAP, 62));

        TextView result = new TextView(this);
        result.setText("جاهز للتحليل");
        result.setTextSize(18);
        root.addView(result, new LinearLayout.LayoutParams(WRAP, 0, 1));

        analyze.setOnClickListener(v -> result.setText("تم تشغيل TradingAI. أضف بيانات السوق للتحليل."));
        setContentView(root);
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }
}
